package com.example.photopager2;

import android.annotation.TargetApi;
import android.app.WallpaperManager;
import android.graphics.*;
import android.os.Build;
import android.service.wallpaper.WallpaperService;
import android.util.LruCache;
import android.view.SurfaceHolder;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class PhotoWallpaperService extends WallpaperService {
    @Override public Engine onCreateEngine() { return new PagerEngine(); }

    class PagerEngine extends Engine {
        SurfaceHolder holder;
        int w, h;
        int sw = 1080, sh = 2400;
        float xOffset = 0f;
        List<File> files = new ArrayList<>();
        final Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG);
        final LruCache<String, Bitmap> cache = new LruCache<String, Bitmap>(48 * 1024 * 1024) {
            @Override protected int sizeOf(String k, Bitmap b) { return b.getByteCount(); }
        };

        @Override public void onCreate(SurfaceHolder sh) {
            super.onCreate(sh);
            holder = sh;
            setOffsetNotificationsEnabled(true);
            try {
                android.util.DisplayMetrics dm = new android.util.DisplayMetrics();
                ((android.view.WindowManager) getSystemService(WINDOW_SERVICE)).getDefaultDisplay().getRealMetrics(dm);
                sw = dm.widthPixels; sh = dm.heightPixels;
                WallpaperManager.getInstance(PhotoWallpaperService.this).suggestDesiredDimensions(sw * 2, sh);
            } catch (Throwable ignored) { }
            if (!isPreview()) {
                new Handler(Looper.getMainLooper()).postDelayed(() -> restoreLock(), 2500);
            }
        }

        void restoreLock() {
            final android.content.Context c = PhotoWallpaperService.this;
            final SharedPreferences sp = c.getSharedPreferences("p", MODE_PRIVATE);
            long last = sp.getLong("last", 0);
            if (!sp.getBoolean("keep_lock", true) || !Photos.lockFile(c).exists()) return;
            if (System.currentTimeMillis() - last < 30000) return;
            sp.edit().putLong("last", System.currentTimeMillis()).apply();
            new Thread(() -> { try { Photos.applyLock(c); } catch (Throwable ignored) { } }).start();
        }

        @Override public void onSurfaceChanged(SurfaceHolder sh, int f, int width, int height) {
            w = width; h = height;
            cache.evictAll();
            files = Photos.list(PhotoWallpaperService.this);
            draw();
        }

        @Override public void onOffsetsChanged(float xo, float yo, float xs, float ys, int xp, int yp) {
            xOffset = xo;
            draw();
        }

        @Override public void onVisibilityChanged(boolean visible) {
            if (visible) { files = Photos.list(PhotoWallpaperService.this); draw(); }
        }

        void draw() {
            if (holder == null || w == 0) return;
            Canvas c = null;
            try {
                c = holder.lockCanvas();
                if (c != null) render(c);
            } catch (Exception ignored) {
            } finally {
                if (c != null) try { holder.unlockCanvasAndPost(c); } catch (Exception ignored) { }
            }
        }

        @TargetApi(34)
        boolean isLockScreen() {
            if (Build.VERSION.SDK_INT < 34) return false;
            try { return getWallpaperFlags() == WallpaperManager.FLAG_LOCK; } catch (Throwable t) { return false; }
        }

        void render(Canvas c) {
            c.drawColor(Color.BLACK);
            float left = (w > sw) ? Math.max(0f, Math.min(1f, xOffset)) * (w - sw) : 0f;
            c.save();
            c.translate(left, 0);
            c.clipRect(0, 0, sw, sh);
            renderInner(c);
            c.restore();
        }

        void renderInner(Canvas c) {
            int n = files.size();
            if (isLockScreen()) {
                File lf = Photos.lockFile(PhotoWallpaperService.this);
                File f = lf.exists() ? lf : (n > 0 ? files.get(0) : null);
                if (f != null) { Bitmap b = loadFit(f); if (b != null) c.drawBitmap(b, 0, 0, paint); }
                return;
            }
            if (n == 0) return;
            float pos = Math.max(0f, Math.min(1f, xOffset)) * (n - 1);
            int i = (int) pos;
            float fr = pos - i;
            Bitmap b1 = loadFit(files.get(i));
            if (b1 != null) c.drawBitmap(b1, -fr * sw, 0, paint);
            if (fr > 0.001f && i + 1 < n) {
                Bitmap b2 = loadFit(files.get(i + 1));
                if (b2 != null) c.drawBitmap(b2, (1 - fr) * sw, 0, paint);
            }
        }

        Bitmap loadFit(File f) {
            String key = f.getPath() + f.lastModified();
            Bitmap cached = cache.get(key);
            if (cached != null) return cached;
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(f.getPath(), o);
            int s = 1;
            while (o.outWidth / (s * 2) >= sw && o.outHeight / (s * 2) >= sh) s *= 2;
            o = new BitmapFactory.Options();
            o.inSampleSize = s;
            Bitmap src = BitmapFactory.decodeFile(f.getPath(), o);
            if (src == null) return null;
            float sc = Math.max((float) sw / src.getWidth(), (float) sh / src.getHeight());
            Bitmap out = Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888);
            Matrix m = new Matrix();
            m.postScale(sc, sc);
            m.postTranslate((sw - src.getWidth() * sc) / 2f, (sh - src.getHeight() * sc) / 2f);
            new Canvas(out).drawBitmap(src, m, paint);
            src.recycle();
            cache.put(key, out);
            return out;
        }
    }
}
