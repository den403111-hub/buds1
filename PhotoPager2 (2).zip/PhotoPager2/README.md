# Фото-шпалери
1. Залий всі файли в GitHub (разом з папкою .github).
2. Вкладка Actions -> Build APK -> дочекайся зеленої галочки.
3. Відкрий збірку -> Artifacts -> PhotoPager-apk -> скачай і встанови APK.
