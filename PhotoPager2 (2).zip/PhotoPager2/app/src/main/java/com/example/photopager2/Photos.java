package com.example.photopager2;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;
import android.app.WallpaperManager;
import android.os.ParcelFileDescriptor;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import android.graphics.Canvas;
import android.graphics.Paint;
import java.io.*;
import java.util.*;

final class Photos {
    static File dir(Context c) { File d = new File(c.getFilesDir(), "photos"); d.mkdirs(); return d; }
    static File lockFile(Context c) { return new File(c.getFilesDir(), "lock.jpg"); }

    static List<File> list(Context c) {
        File[] f = dir(c).listFiles();
        List<File> l = new ArrayList<>();
        if (f != null) { Arrays.sort(f); l.addAll(Arrays.asList(f)); }
        return l;
    }

    static void save(Context c, Uri uri, File out) throws IOException {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        try (InputStream in = c.getContentResolver().openInputStream(uri)) { BitmapFactory.decodeStream(in, null, o); }
        int s = 1;
        while (Math.max(o.outWidth, o.outHeight) / s > 3000) s *= 2;
        o = new BitmapFactory.Options();
        o.inSampleSize = s;
        Bitmap b;
        try (InputStream in = c.getContentResolver().openInputStream(uri)) { b = BitmapFactory.decodeStream(in, null, o); }
        if (b == null) throw new IOException("decode failed");
        int rot = 0;
        try (InputStream in = c.getContentResolver().openInputStream(uri)) {
            int ori = new ExifInterface(in).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1);
            if (ori == 6) rot = 90; else if (ori == 3) rot = 180; else if (ori == 8) rot = 270;
        } catch (Exception ignored) { }
        if (rot != 0) {
            Matrix m = new Matrix();
            m.postRotate(rot);
            Bitmap r = Bitmap.createBitmap(b, 0, 0, b.getWidth(), b.getHeight(), m, true);
            b.recycle();
            b = r;
        }
        try (FileOutputStream fo = new FileOutputStream(out)) { b.compress(Bitmap.CompressFormat.JPEG, 90, fo); }
        b.recycle();
    }

    /** Ставить lock.jpg ТІЛЬКИ на екран блокування. */
    static void applyLock(Context c) throws Exception {
        File f = lockFile(c);
        if (!f.exists()) return;
        DisplayMetrics dm = new DisplayMetrics();
        ((WindowManager) c.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay().getRealMetrics(dm);
        int W = dm.widthPixels, H = dm.heightPixels;
        Bitmap src = BitmapFactory.decodeFile(f.getPath());
        if (src == null) return;
        float sc = Math.max((float) W / src.getWidth(), (float) H / src.getHeight());
        Bitmap out = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888);
        Matrix m = new Matrix();
        m.postScale(sc, sc);
        m.postTranslate((W - src.getWidth() * sc) / 2f, (H - src.getHeight() * sc) / 2f);
        new Canvas(out).drawBitmap(src, m, new Paint(Paint.FILTER_BITMAP_FLAG));
        WallpaperManager.getInstance(c).setBitmap(out, null, true, WallpaperManager.FLAG_LOCK);
    }

    /** Пробує зберегти ПОТОЧНЕ фото блокування в lock.jpg. */
    static boolean captureLock(Context c) {
        try {
            ParcelFileDescriptor pfd = WallpaperManager.getInstance(c).getWallpaperFile(WallpaperManager.FLAG_LOCK);
            if (pfd == null) return false;
            Bitmap b = BitmapFactory.decodeFileDescriptor(pfd.getFileDescriptor());
            pfd.close();
            if (b == null) return false;
            try (FileOutputStream fo = new FileOutputStream(lockFile(c))) { b.compress(Bitmap.CompressFormat.JPEG, 92, fo); }
            return true;
        } catch (Throwable e) { return false; }
    }
}
