package com.example.photopager2;

import android.app.Activity;
import android.app.WallpaperManager;
import android.content.ClipData;
import android.content.ComponentName;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    static final int REQ_PHOTOS = 1, REQ_LOCK = 2;
    TextView info;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int p = (int) (24 * getResources().getDisplayMetrics().density);
        root.setPadding(p, p * 2, p, p);
        TextView t = new TextView(this);
        t.setText("Фото-шпалери 2\nФото змінюються при гортанні, а блокування повертається саме");
        t.setTextSize(18);
        root.addView(t);
        info = new TextView(this);
        info.setPadding(0, p / 2, 0, p / 2);
        root.addView(info);
        addBtn(root, "1. Додати фото на робочий стіл", v -> pick(REQ_PHOTOS, true));
        addBtn(root, "2. Вибрати фото для екрана блокування", v -> pick(REQ_LOCK, false));
        addBtn(root, "2б. Взяти поточне фото блокування", v -> {
            boolean ok = Photos.captureLock(this);
            Toast.makeText(this, ok ? "Збережено" : "Не вийшло, вибери фото кнопкою 2", Toast.LENGTH_LONG).show();
            refresh();
        });
        addBtn(root, "3. Встановити шпалери (блокування не чіпаю)", v -> {
            getSharedPreferences("p", MODE_PRIVATE).edit().putLong("last", 0).apply();
            if (!Photos.lockFile(this).exists()) Photos.captureLock(this);
            if (!Photos.lockFile(this).exists()) Toast.makeText(this, "Не вдалось запам'ятати блокування - спершу вибери фото кнопкою 2", Toast.LENGTH_LONG).show();
            Intent i = new Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER);
            i.putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                    new ComponentName(this, PhotoWallpaperService.class));
            startActivity(i);
        });
        addBtn(root, "Очистити всі фото", v -> {
            for (File f : Photos.list(this)) f.delete();
            Photos.lockFile(this).delete();
            refresh();
        });
        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        setContentView(sv);
        refresh();
    }

    void addBtn(LinearLayout root, String text, View.OnClickListener l) {
        Button btn = new Button(this);
        btn.setText(text);
        btn.setAllCaps(false);
        btn.setOnClickListener(l);
        root.addView(btn);
    }

    void pick(int req, boolean multi) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("image/*");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, multi);
        startActivityForResult(i, req);
    }

    void refresh() {
        info.setText("Фото: " + Photos.list(this).size()
                + "\nФото для блокування: " + (Photos.lockFile(this).exists() ? "є" : "НЕМА - без нього блокування не відновиться"));
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        if (res != RESULT_OK || data == null) return;
        List<Uri> uris = new ArrayList<>();
        ClipData cd = data.getClipData();
        if (cd != null) for (int i = 0; i < cd.getItemCount(); i++) uris.add(cd.getItemAt(i).getUri());
        else if (data.getData() != null) uris.add(data.getData());
        Toast.makeText(this, "Зберігаю...", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            long ts = System.currentTimeMillis();
            int n = 0;
            for (Uri u : uris) {
                try {
                    File out = req == REQ_LOCK ? Photos.lockFile(this)
                            : new File(Photos.dir(this), "p_" + ts + "_" + String.format("%03d", n++) + ".jpg");
                    Photos.save(this, u, out);
                } catch (Exception e) { /* skip */ }
            }
            runOnUiThread(this::refresh);
        }).start();
    }
}
