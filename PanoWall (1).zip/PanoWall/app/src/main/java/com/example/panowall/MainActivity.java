package com.example.panowall;

import android.app.Activity;
import android.app.WallpaperManager;
import android.content.ClipData;
import android.content.Intent;
import android.graphics.*;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.*;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    static final int REQ = 1;
    final List<Uri> uris = new ArrayList<>();
    TextView status;
    EditText pages;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int p = (int) (24 * getResources().getDisplayMetrics().density);
        root.setPadding(p, p * 2, p, p);
        TextView t = new TextView(this);
        t.setText("Фото на столи\nСтавить шпалери ТІЛЬКИ на головний екран. Блокування не чіпає.");
        t.setTextSize(18);
        root.addView(t);
        status = new TextView(this);
        status.setPadding(0, p / 2, 0, p / 2);
        status.setText("Фото не вибрано");
        root.addView(status);
        btn(root, "1. Вибрати фото", v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.setType("image/*");
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            startActivityForResult(i, REQ);
        });
        TextView l = new TextView(this);
        l.setText("Скільки сторінок на столі (точки внизу):");
        l.setPadding(0, p / 2, 0, 0);
        root.addView(l);
        pages = new EditText(this);
        pages.setInputType(InputType.TYPE_CLASS_NUMBER);
        pages.setText("5");
        root.addView(pages);
        btn(root, "2. Поставити ТІЛЬКИ на головний екран", v -> apply());
        setContentView(root);
    }

    void btn(LinearLayout root, String s, View.OnClickListener l) {
        Button x = new Button(this);
        x.setText(s);
        x.setAllCaps(false);
        x.setOnClickListener(l);
        root.addView(x);
    }

    @Override protected void onActivityResult(int req, int res, Intent d) {
        if (req != REQ || res != RESULT_OK || d == null) return;
        uris.clear();
        ClipData cd = d.getClipData();
        if (cd != null) for (int i = 0; i < cd.getItemCount(); i++) uris.add(cd.getItemAt(i).getUri());
        else if (d.getData() != null) uris.add(d.getData());
        status.setText("Вибрано фото: " + uris.size());
        pages.setText(String.valueOf(Math.max(1, uris.size())));
    }

    void apply() {
        if (uris.isEmpty()) { Toast.makeText(this, "Спочатку вибери фото", Toast.LENGTH_SHORT).show(); return; }
        int pp;
        try { pp = Integer.parseInt(pages.getText().toString().trim()); } catch (Exception e) { pp = uris.size(); }
        final int P = Math.max(1, Math.min(15, pp));
        status.setText("Працюю...");
        new Thread(() -> {
            String msg;
            try {
                DisplayMetrics dm = new DisplayMetrics();
                getWindowManager().getDefaultDisplay().getRealMetrics(dm);
                int W = dm.widthPixels, H = dm.heightPixels;
                float sc = (float) Math.min(1.0, Math.min(8192.0 / (P * W), Math.sqrt(24e6 / ((double) P * W * H))));
                int tw = Math.round(W * sc), th = Math.round(H * sc);
                Bitmap pano = Bitmap.createBitmap(tw * P, th, Bitmap.Config.ARGB_8888);
                Canvas cv = new Canvas(pano);
                for (int k = 0; k < P; k++) {
                    Bitmap tile = loadTile(uris.get(k % uris.size()), tw, th);
                    if (tile != null) { cv.drawBitmap(tile, k * tw, 0, null); tile.recycle(); }
                }
                WallpaperManager wm = WallpaperManager.getInstance(this);
                try { wm.suggestDesiredDimensions(tw * P, th); } catch (Throwable ignored) { }
                wm.setBitmap(pano, null, true, WallpaperManager.FLAG_SYSTEM);
                msg = "Готово: шпалери стола поставлено (сторінок: " + P + "). Погортай столи.\n"
                        + "Якщо картинка не рухається - увімкни прокручування шпалер у налаштуваннях лаунчера.";
            } catch (Throwable e) { msg = "Помилка: " + e; }
            final String fm = msg;
            runOnUiThread(() -> status.setText(fm));
        }).start();
    }

    Bitmap loadTile(Uri u, int tw, int th) throws Exception {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        try (InputStream in = getContentResolver().openInputStream(u)) { BitmapFactory.decodeStream(in, null, o); }
        int s = 1;
        while (o.outWidth / (s * 2) >= tw && o.outHeight / (s * 2) >= th) s *= 2;
        o = new BitmapFactory.Options();
        o.inSampleSize = s;
        Bitmap src;
        try (InputStream in = getContentResolver().openInputStream(u)) { src = BitmapFactory.decodeStream(in, null, o); }
        if (src == null) return null;
        int rot = 0;
        try (InputStream in = getContentResolver().openInputStream(u)) {
            int ori = new ExifInterface(in).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1);
            if (ori == 6) rot = 90; else if (ori == 3) rot = 180; else if (ori == 8) rot = 270;
        } catch (Exception ignored) { }
        if (rot != 0) {
            Matrix m = new Matrix();
            m.postRotate(rot);
            Bitmap r = Bitmap.createBitmap(src, 0, 0, src.getWidth(), src.getHeight(), m, true);
            src.recycle();
            src = r;
        }
        float k = Math.max((float) tw / src.getWidth(), (float) th / src.getHeight());
        Bitmap out = Bitmap.createBitmap(tw, th, Bitmap.Config.ARGB_8888);
        Matrix m = new Matrix();
        m.postScale(k, k);
        m.postTranslate((tw - src.getWidth() * k) / 2f, (th - src.getHeight() * k) / 2f);
        new Canvas(out).drawBitmap(src, m, new Paint(Paint.FILTER_BITMAP_FLAG));
        src.recycle();
        return out;
    }
}
